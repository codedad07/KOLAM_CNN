import tensorflow as tf
import numpy as np
import cv2
import logging

# --- Configuration ---
CLASSIFIER_MODEL_PATH = 'kolamnet_resnet50_model.keras' # Path to your trained CNN
IMAGE_PATH = 'testimg.jpg' # <<<<<< CHANGE THIS TO YOUR TEST IMAGE
IMG_SIZE = (224, 224)
CLASS_NAMES = ['chikku', 'freehand', 'padi', 'pulli']

# --- Setup Logging ---
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def predict_kolam_type(model, image_path):
    """Loads an image and predicts its type using the trained CNN model."""
    try:
        image = cv2.imread(image_path)
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image_resized = cv2.resize(image_rgb, IMG_SIZE)
        image_batch = np.expand_dims(image_resized, axis=0)
        
        predictions = model.predict(image_batch)
        predicted_index = np.argmax(predictions[0])
        predicted_category = CLASS_NAMES[predicted_index]
        return predicted_category
    except Exception as e:
        logging.error(f"Failed during prediction: {e}")
        return None

def detect_dots(image):
    """Finds and draws circles on an image. Returns the analyzed image and dot count."""
    output_image = image.copy()
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, dp=1.2, minDist=20,
                               param1=50, param2=15, minRadius=5, maxRadius=15)
    dot_count = 0
    if circles is not None:
        circles = np.round(circles[0, :]).astype("int")
        for (x, y, r) in circles:
            cv2.circle(output_image, (x, y), r, (0, 255, 0), 2)
        dot_count = len(circles)
    return output_image, dot_count

def detect_lines(image):
    """Finds and draws straight lines on an image. Returns the analyzed image and line count."""
    output_image = image.copy()
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=50,
                            minLineLength=50, maxLineGap=10)
    line_count = 0
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(output_image, (x1, y1), (x2, y2), (0, 0, 255), 3)
        line_count = len(lines)
    return output_image, line_count


if __name__ == '__main__':
    # 1. Load the classification model
    logging.info(f"Loading classifier model from {CLASSIFIER_MODEL_PATH}...")
    try:
        classifier_model = tf.keras.models.load_model(CLASSIFIER_MODEL_PATH)
    except Exception as e:
        logging.error(f"Could not load model. Please run train_cnn.py first. Error: {e}")
        exit()

    # 2. Predict the Kolam type
    logging.info(f"Analyzing image: {IMAGE_PATH}")
    prediction = predict_kolam_type(classifier_model, IMAGE_PATH)
    
    if not prediction:
        exit()

    logging.info(f"Classifier predicted type: '{prediction}'")
    
    # 3. Load the original image for analysis
    original_image = cv2.imread(IMAGE_PATH)
    analyzed_image = original_image.copy()
    analysis_text = f"Type: {prediction}"

    # 4. Based on prediction, run the correct analysis
    if prediction == 'pulli':
        logging.info("Pulli Kolam detected. Running dot detection...")
        analyzed_image, count = detect_dots(original_image)
        analysis_text += f" | Dots: {count}"
    elif prediction == 'padi':
        logging.info("Padi Kolam detected. Running line detection...")
        analyzed_image, count = detect_lines(original_image)
        analysis_text += f" | Lines: {count}"
    else:
        logging.info(f"No specific analysis for type '{prediction}'.")

    # 5. Display the final result
    # Add the result text to the top-left of the image
    cv2.putText(analyzed_image, analysis_text, (20, 40), 
                cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
                
    cv2.imshow("Kolam Analysis Result", analyzed_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()