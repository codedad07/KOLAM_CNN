import tensorflow as tf
import numpy as np
import cv2
import logging

# --- Configuration ---
# --- THE FIX IS ON THIS LINE ---
MODEL_PATH = 'kolamnet_resnet50_model.keras' # Updated to the correct model name
IMAGE_PATH = 'testimg3.jpg'              # Change this to your test image name
IMG_SIZE = (224, 224)
# Make sure this list is in the same alphabetical order as the training folders
CLASS_NAMES = ['chikku', 'freehand', 'padi', 'pulli'] 

# --- 1. Load the trained Keras model ---
try:
    model = tf.keras.models.load_model(MODEL_PATH)
except Exception as e:
    logging.error(f"Could not load model. Please run train_cnn.py first. Error: {e}")
    exit()

# --- 2. Load and process the image ---
try:
    image = cv2.imread(IMAGE_PATH)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB) # Keras expects RGB
    image = cv2.resize(image, IMG_SIZE)
    # Convert image to a batch of 1
    image_batch = np.expand_dims(image, axis=0)
except Exception as e:
    logging.error(f"Could not process image. Check the IMAGE_PATH. Error: {e}")
    exit()

# --- 3. Make a prediction ---
predictions = model.predict(image_batch)
# The output is an array of probabilities for each class
# We find the index of the class with the highest probability
predicted_index = np.argmax(predictions[0])
predicted_category = CLASS_NAMES[predicted_index]
confidence = np.max(predictions[0]) * 100

print("\n" + "="*40)
print(f"🔎 Prediction: The Kolam is of type '{predicted_category}'")
print(f"Confidence: {confidence:.2f}%")
print("="*40)