import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
# --- CHANGED: Import ResNet50 and its specific preprocessor ---
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.applications.resnet50 import preprocess_input
import logging

# --- Setup Logging ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Configuration ---
DATA_DIR = 'kolam_dataset_cleaned'
IMG_SIZE = (224, 224)
BATCH_SIZE = 32
EPOCHS = 10 

# --- 1. Load Data Directly from Folders ---
logging.info("Loading and splitting the dataset...")
train_dataset = tf.keras.utils.image_dataset_from_directory(
    DATA_DIR,
    validation_split=0.2,
    subset="training",
    seed=123,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    color_mode='rgb'
)
validation_dataset = tf.keras.utils.image_dataset_from_directory(
    DATA_DIR,
    validation_split=0.2,
    subset="validation",
    seed=123,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    color_mode='rgb'
)
CLASS_NAMES = train_dataset.class_names
logging.info(f"Found class names: {CLASS_NAMES}")
train_dataset = train_dataset.cache().prefetch(buffer_size=tf.data.AUTOTUNE)
validation_dataset = validation_dataset.cache().prefetch(buffer_size=tf.data.AUTOTUNE)

# --- 2. Build the Model using ResNet50 ---
logging.info("Building the model using transfer learning with ResNet50...")
data_augmentation = keras.Sequential([
    layers.RandomFlip("horizontal"),
    layers.RandomRotation(0.1),
    layers.RandomZoom(0.1),
])

# --- CHANGED: Load ResNet50 as the base model ---
base_model = ResNet50(
    input_shape=(*IMG_SIZE, 3),
    include_top=False,
    weights='imagenet'
)
base_model.trainable = False

# Create our new model on top
inputs = keras.Input(shape=(*IMG_SIZE, 3))
x = data_augmentation(inputs)
# --- ADDED: Apply the required ResNet50 preprocessing ---
x = preprocess_input(x)
x = base_model(x, training=False)
x = layers.GlobalAveragePooling2D()(x)
x = layers.Dropout(0.2)(x)
outputs = layers.Dense(len(CLASS_NAMES), activation='softmax')(x)
model = keras.Model(inputs, outputs)

# --- 3. Compile the Model ---
logging.info("Compiling the model...")
model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)
model.summary()

# --- 4. Train the Model ---
logging.info(f"Starting training for {EPOCHS} epochs...")
history = model.fit(
    train_dataset,
    validation_data=validation_dataset,
    epochs=EPOCHS
)

# --- 5. Save the Final Model ---
logging.info("Training complete. Saving the model...")
model.save('kolamnet_resnet50_model.keras') # Saved with a new name
logging.info("Model saved successfully as 'kolamnet_resnet50_model.keras'")