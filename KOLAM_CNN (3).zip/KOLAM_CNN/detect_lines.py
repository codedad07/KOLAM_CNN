import cv2
import numpy as np
import logging

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

# --- Load the image ---
image_path = 'kolam_with_lines.jpg' # Use an image with straight lines, like a Padi Kolam
image = cv2.imread(image_path)
if image is None:
    logging.error(f"Could not load image from {image_path}")
    exit()

output = image.copy()
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# --- Use Canny Edge Detection ---
edges = cv2.Canny(gray, 50, 150, apertureSize=3)

# --- Use Probabilistic Hough Line Transform ---
# minLineLength: The minimum length of a line to be considered.
# maxLineGap: The maximum gap between segments to be treated as a single line.
lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=50,
                        minLineLength=50, maxLineGap=10)

line_count = 0
if lines is not None:
    for line in lines:
        x1, y1, x2, y2 = line[0]
        cv2.line(output, (x1, y1), (x2, y2), (0, 0, 255), 2)
    line_count = len(lines)

logging.info(f"Found {line_count} straight lines in the image.")

# Show the output image
cv2.imshow("Detected Lines", output)
cv2.waitKey(0)
cv2.destroyAllWindows()