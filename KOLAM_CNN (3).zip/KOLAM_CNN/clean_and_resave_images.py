import os
from PIL import Image
import logging

# --- Setup Logging ---
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

# --- Configuration ---
SOURCE_DIR = 'kolam_dataset'
CLEANED_DIR = 'kolam_dataset_cleaned'
IMAGE_SIZE = (224, 224) # Resize while we clean

success_count = 0
fail_count = 0

if not os.path.exists(CLEANED_DIR):
    os.makedirs(CLEANED_DIR)

logging.info(f"Starting to clean and re-save images from '{SOURCE_DIR}' to '{CLEANED_DIR}'...")

# Walk through all subdirectories and files
for root, subdirs, files in os.walk(SOURCE_DIR):
    # Create corresponding subdirectories in the cleaned folder
    for subdir in subdirs:
        new_subdir_path = os.path.join(CLEANED_DIR, subdir)
        if not os.path.exists(new_subdir_path):
            os.makedirs(new_subdir_path)

    for filename in files:
        file_path = os.path.join(root, filename)
        
        # Create the path for the new, cleaned image
        relative_path = os.path.relpath(root, SOURCE_DIR)
        new_file_path = os.path.join(CLEANED_DIR, relative_path, filename)
        
        try:
            with Image.open(file_path) as img:
                # Convert to RGB, resize, and save as JPEG
                img.convert('RGB').resize(IMAGE_SIZE).save(new_file_path, "JPEG", quality=95)
            success_count += 1
        except Exception as e:
            logging.error(f"Could not process file: {file_path} due to error: {e}")
            fail_count += 1

logging.info("\n" + "="*30)
logging.info("      CLEANING COMPLETE")
logging.info("="*30)
logging.info(f"Successfully processed and saved: {success_count} images.")
logging.info(f"Failed to process: {fail_count} images.")
if fail_count == 0:
    logging.info("✅ All images were processed successfully!")
else:
    logging.error("❌ Some images failed. Check the errors above.")