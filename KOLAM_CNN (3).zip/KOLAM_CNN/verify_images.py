import os
from PIL import Image
import logging

# --- Setup Logging ---
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

# --- Configuration ---
DATA_DIR = 'kolam_dataset'
corrupted_files = []

logging.info(f"Scanning directory: '{DATA_DIR}' for corrupted images...")

# Walk through all subdirectories and files
for root, _, files in os.walk(DATA_DIR):
    for filename in files:
        file_path = os.path.join(root, filename)
        try:
            # Try to open the image and load its data
            with Image.open(file_path) as img:
                img.load() # This forces the image data to be read
        except (IOError, SyntaxError) as e:
            # If an error occurs, it's likely a corrupted file
            logging.warning(f"Found corrupted file: {file_path}")
            corrupted_files.append(file_path)

# --- Summary ---
if not corrupted_files:
    logging.info("\n✅ Scan complete. No corrupted images found!")
else:
    logging.error(f"\n❌ Scan complete. Found {len(corrupted_files)} corrupted file(s).")
    logging.error("Please manually delete the files listed above and then run your training script again.")