import cv2
import numpy as np
import logging

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

# --- Load the image ---
image_path = 'kolam_with_dots.jpg' # Change to your image path
image = cv2.imread(image_path)
if image is None:
    logging.error(f"Could not load image from {image_path}")
    exit()

output = image.copy()
# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# --- Use Hough Circle Transform ---
# This function's parameters need careful tuning for your specific images
# param1: Higher threshold for Canny edge detector
# param2: Accumulator threshold (smaller value = more circles detected)
# minRadius / maxRadius: The size of the dots you're looking for
circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, dp=1.2, minDist=20,
                           param1=50, param2=15, minRadius=5, maxRadius=15)

dot_count = 0
if circles is not None:
    # Convert the (x, y, r) coordinates to integers
    circles = np.round(circles[0, :]).astype("int")
    
    # Loop over the detected circles
    for (x, y, r) in circles:
        # Draw the circle in the output image
        cv2.circle(output, (x, y), r, (0, 255, 0), 2)
        # Draw a rectangle corresponding to the center of the circle
        cv2.rectangle(output, (x - 2, y - 2), (x + 2, y + 2), (0, 128, 255), -1)
    
    dot_count = len(circles)

logging.info(f"Found {dot_count} dots in the image.")

# Show the output image
cv2.imshow("Detected Dots", output)
cv2.waitKey(0)
cv2.destroyAllWindows()